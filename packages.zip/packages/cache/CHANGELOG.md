# Change Log

## Version 1.2.0

1. Change README

## Version 1.1.0

1. Fix the duplicated result in data store.

## Version 1.0.0

1. Create `FileCache`
2. Create `ApcCache`
3. Create `MemCache`