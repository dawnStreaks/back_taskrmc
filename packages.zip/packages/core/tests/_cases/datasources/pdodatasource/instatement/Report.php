<?php

class Report extends DbReport
{

}