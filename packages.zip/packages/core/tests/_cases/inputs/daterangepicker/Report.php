<?php

class Report extends \koolreport\KoolReport
{
    use \koolreport\bootstrap3\Theme;
}