<?php

class Report extends \koolreport\KoolReport
{
    use \koolreport\amazing\Theme;
}