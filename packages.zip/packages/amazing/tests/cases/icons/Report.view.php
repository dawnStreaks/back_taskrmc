<?php
use \koolreport\amazing\ChartCard;
?>
<html>
    <head>
        <title>Test simpleline and font-awesome</title>
    </head>
    <body>
        <h1>Test simpleline and font-awesome</h1>

        <i class="fa fa-users"></i>
        <i class="icon-bubble"></i>
    </body>
</html>