<?php

namespace koolreport\chartjs;
use \koolreport\core\Utility;

class ColumnChart extends BarChart
{
    protected $type="bar";
}